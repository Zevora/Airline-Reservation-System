/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airplane;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import javafx.beans.binding.Bindings;

/**
 *
 * @author Owner
 */
public class Map extends Flight{

    public static char[][] flightMap = new char[8][10]; //create a map of 8 columns by 10 rows //need to name after fNumber

    public Map(String[] flightRegistry) throws IOException { //netbeans complains if this isn't present
        super(flightRegistry);
    }


    static void createFlightMap(String flightID) throws IOException{

        System.out.println("Beginning createFlightMap . . ."); //for debugging
        FileWriter map = new FileWriter("Flight #"+flightID+".txt"); //names file written to after flightID


        System.out.println("Map: "+flightID+" created"); //for debugging
        int count=1;//counter that is equal to row+1 for row numbering

        for(int row=0;row<=9;row++){
            char alphabet = 'A';
            map.write(count+"\t");

            for(int col=0;col<2;col++){ //prints 'ab' before tabbing over
                flightMap[col][row] = alphabet;
                map.write(flightMap[col][row]+' ');
                System.out.print(flightMap[col][row]);//for debugging
                alphabet++;
            }
            map.write(' ');

            for(int col=3;col<6;col++){ //print 'cde' before tabbing over
                flightMap[col][row] = alphabet;
                map.write(flightMap[col][row]+' ');
                System.out.print(flightMap[col][row]);//for debugging
                alphabet++;
            }
            map.write(' ');

            for(int col=6;col<8;col++){ //prints 'fg' before tabbing over
                flightMap[col][row] = alphabet;
                map.write(flightMap[col][row]+' ');
                System.out.print(flightMap[col][row]);//for debugging
                alphabet++;
            }
            count++;//increment row counter
            map.write(System.getProperty("line.separator"));//skips line in file
            System.out.println("\n");//for debugging
        }

        System.out.println("Map filled"); //for debugging
        map.close();
        System.out.println("MapMaker closed"); //for debugging

    }

    public static StringBuilder updateMap(String flightID, String row, String col) throws IOException{ 

        System.out.println("Made it to update map . . ."+"\nRow: "+row+"\nColumn: "+col);
        
        //reading in original map file
        File originalFlightMap = new File("C:\\Users\\Owner\\Desktop\\Programming2\\GroupProject\\airplane Alternate\\Flight #"+flightID+".txt");
        Scanner scanner = new Scanner(originalFlightMap);     

        //appending to list
        List<String> lines = new ArrayList<String>();
        while(scanner.hasNextLine()){
            lines.add(scanner.nextLine());
        }
        
        //restructuring to string array
        String[] flightMap = lines.toArray(new String[0]);
        
        System.out.println("Preparing to enter for loop . . . ");
        
        //search/iteratre through array 
        for(int i =0; i<flightMap.length;i++) { //begin searching through textfile for element matching row
            if(flightMap[i].contains(row)){ //If string index contains row value, then search for substring of col value
                System.out.println("Row "+row+" found!");
                
                //*************************************************
                String[] subString = flightMap[i].split("");;
                for(int j=0; j<subString.length;j++){
                    if(subString[j] == "X"){System.out.println("Error . . . This seat is already taken!");}
                    else{flightMap[i] = flightMap[i].replace(col, "X");}//replaces the occurence of col value with an "X"
                }
                
                
                //CHECKING FOR SEAT OCCUPANCY DOESN'T WORK
                //if(flightMap[i].contains("X")){System.out.println("Error . . . This seat is already taken!");}//if seat taken, produce error
                //else{flightMap[i] = flightMap[i].replace(col, "X");}//replaces the occurence of col value with an "X"
            }
            else{System.out.println("Row not found at index "+i);}
        }
        
        System.out.println("Displaying revised map: "+Arrays.toString(flightMap));
        
        //create stringbuilder to send back to reservationController to set display label to and to overwrite original map file
        StringBuilder updatedSeatingMap = new StringBuilder();
        //set filePath to be used for grabbing the file
        String filePath = "C:\\Users\\Owner\\Desktop\\Programming2\\GroupProject\\airplane Alternate\\Flight #"+flightID+".txt";
        System.out.println("Sending to "+filePath+". Filename: "+flightID);

        try (BufferedReader br = new BufferedReader(new FileReader(filePath)))
        {
            String sCurrentLine; while ((sCurrentLine = br.readLine()) != null)
        {
            updatedSeatingMap.append(sCurrentLine).append("\n");
        }
        }
        System.out.println("Made it past bufferedreader");
        
        //Overwriting old map file
        FileWriter overWrite = new FileWriter(filePath);     //Second check for existing while setting append
        
        for(int i=0;i<10;i++){
        overWrite.write(flightMap[i]);
        overWrite.write(System.getProperty("line.separator"));             //Adds a line to seperate
        }

        overWrite.close();//close file
        
        return updatedSeatingMap;
    }
}
