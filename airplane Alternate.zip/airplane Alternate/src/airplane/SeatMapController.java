/*An attempt to fix displaySeatMap

 */

package airplane;

import java.io.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Label;
import javafx.scene.text.Text;

import javax.swing.*;

public class SeatMapController extends ReservationController
{

    @FXML
    private Label displayMapLabel;

    @FXML
    private Text availableSeatLabel;

    @FXML
    private TextField rowField;

    @FXML
    private Button backButton;

    @FXML
    private Label flightLabel;

    @FXML
    private AnchorPane seatMapPane;

    @FXML
    private TextField columnField;

    //initialize location to null
    String r = ""; String c = "";
    //initialize fNumber to reservationID's fNumber
    String n;

    String[] updatedReservationInfo = {};



    @Override //chaos necessary to execute the reserve function upon scene loading
    public void initialize(URL url, ResourceBundle rb)
    {

        /*
        try {
            initialGeneration();
        } catch (IOException ex) {
            Logger.getLogger(AllFlightsController.class.getName()).log(Level.SEVERE, null, ex);
        }*/
    }


    public void initialGeneration() throws IOException
    {
        System.out.println("Initial Generation Method reached");

        n = flightNum.getText();

        //create StringBuilder called seatingMap
        StringBuilder seatingMap = new StringBuilder();
        //set filePath to be used for grabbing the file
        String filePath = "C:\\Users\\Lyan\\Documents\\IntelliJ Projects\\airplane Alternate\\Flight #"+n+".txt";
        System.out.println("Sending to "+filePath+". Filename: "+n);

        try (BufferedReader br = new BufferedReader(new FileReader(filePath)))
        {
            String sCurrentLine; while ((sCurrentLine = br.readLine()) != null)
        {
            seatingMap.append(sCurrentLine).append("\n");
        }
        }
        System.out.println("Made it past bufferedreader");
        System.out.println(seatingMap+"\nSuccessfully Printed!\n");//printing seating map to screen for debugging

        displayMapLabel.setText(seatingMap.toString()); //Cannot get Label to display on scene pane, causes crash
    }

    @FXML
    void reserve(ActionEvent event) throws FileNotFoundException, IOException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException //button to Confirm the Reservation
    {
        System.out.println("Reserve Reached");
        String fNumber = flightNum.getText();
        //May make the actual printing into its own function to be called twice -- once before and once after update
        //create StringBuilder called seatingMap
        StringBuilder seatMap = new StringBuilder();
        //set filePath to be used for grabbing the file
        String filePath = "C:\\Users\\Lyan\\Documents\\IntelliJ Projects\\airplane Alternate\\Flight #"+fNumber+".txt";
        System.out.println("Sending to "+filePath+". Filename: "+fNumber);

        /* MY ATTEMPT AT FIXING DISPLAY SEAT MAP CONTROLLER ***************
        try(FileWriter fw = new FileWriter(filePath, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw))
        {
            out.println("the text");

            out.println("more text");
        }
        */


        try (BufferedReader br = new BufferedReader(new FileReader(filePath)))
        {
            String sCurrentLine; while ((sCurrentLine = br.readLine()) != null)
        {
            seatMap.append(sCurrentLine).append("\n");
        }
        }

        //CREATE TEXT AREA AND PRINT STRING BUILDER

        System.out.println("Made it past bufferedreader");
        System.out.println(seatMap+"\nSuccessfully Printed!\n");//printing seating map to screen for debugging

        System.out.println("Before the displayLabel");
        displayMapLabel.setText(seatMap.toString()); //Cannot get Label to display on scene pane, causes crash
        System.out.println("After the displayLabel");


        //redefine variables
        r = rowField.getText(); c = columnField.getText();
        String seatSelection = r+c+"";
        System.out.println("Column: "+c+"\nRow: "+r);//for debugging

        if((Character.isDigit(c.charAt(0))) || (Character.isLetter(r.charAt(0))))
        {System.err.println("Error . . . Invalid entry");}

        char[][] newFlightMap=null;
        newFlightMap[Integer.parseInt(r)][Integer.parseInt(c)] = 'X';//sets desired seating location to and 'X'//need to test
        Map.updateMap(fNumber, newFlightMap);//uses updateMap to create new, updated map

        //update reservation using reflection -- still wrapping my head around it
        System.out.println("attempting to update reservation . . . ");
        Method setSeat = reservationID.getClass().getMethod("setSeat"); //get the setSeat method from reservationID
        Object something = setSeat.invoke(reservationID); //placeholder to hold this reused bit
        something.getClass().getMethod("setSeat").invoke(something, seatSelection); //execute setSeat and pass row and col
        System.out.println("reservation, might be, updated");
    }


    @FXML
    void goBack(ActionEvent event) throws IOException   //Goes back to the main menu
    {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        seatMapPane.getChildren().setAll(pane);
    }


}
