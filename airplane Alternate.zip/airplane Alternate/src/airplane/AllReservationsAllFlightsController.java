/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airplane;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;

import javafx.beans.value.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Lyan
 */
public class AllReservationsAllFlightsController implements Initializable 
{

    @FXML
    private Button enterButton;

    @FXML
    private Button backButton;

    @FXML
    private TextField flightNumberField;

    @FXML
    private AnchorPane allReservationPane;

    @FXML
    private Label reservationLabel;

    @FXML
    void goBack(ActionEvent event) throws IOException
    {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        allReservationPane.getChildren().setAll(pane);   
    }


    @FXML
    void loadAllReservations() throws IOException{

        //create StringBuilder called seatingMap
        StringBuilder allFlights = new StringBuilder();
        //set filePath to be used for grabbing the file
        String filePath = "C:\\Users\\Lyan\\Documents\\IntelliJ Projects\\airplane Alternate\\reservations.txt";
        System.out.println("Sending to "+filePath);

        try (BufferedReader br = new BufferedReader(new FileReader(filePath)))
        {
            String sCurrentLine; while ((sCurrentLine = br.readLine()) != null)
        {
            allFlights.append(sCurrentLine).append("\n");
        }
        }
        System.out.println("Made it past bufferedreader");
        System.out.println(allFlights+"\nSuccessfully Printed!\n");//printing seating map to screen for debugging

        reservationLabel.setText(allFlights.toString());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        try {
            loadAllReservations();
        } catch (IOException ex) {
            Logger.getLogger(AllFlightsController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
}
