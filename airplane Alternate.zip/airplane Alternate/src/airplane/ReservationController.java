/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airplane;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;


/**
 * FXML Controller class
 *
 * @author Lyan
 */


public class ReservationController implements Initializable
{

 @FXML
 private AnchorPane reservationMakerPane;

 @FXML
 public TextField flightNum;

 @FXML
 private TextField numSeats;

 @FXML
 public TextField passID;

 @FXML
 private Button backButton;

 @FXML
 private TextField passName;

 String reservationID = "";
 String seatNum="";
boolean exists;

 @FXML
 public void displaySeatMap (ActionEvent event) throws IOException
 {
  String fNumber = flightNum.getText(); //get flight number from textfield
  String passengerID = passID.getText(); //get passenger id from textfield
  reservationID = passengerID; //set reservationID to passengerID -- to be used for file/var naming
  String passengerName = passName.getText(); //get passenger name from textfield
  System.out.println("Variables defined"); //for debugging

  String[] reservationInfo = {passengerID, passengerName, seatNum, fNumber}; //create string to contain reservationInfo

  //create a flight reservation named after reservationID -- round about way of using passengerID
  File filePath = new File("C:\\Users\\Lyan\\Documents\\IntelliJ Projects\\airplane Alternate\\reservations.txt"); //Setting the filePath
  exists = filePath.exists();     //sets the exist case


  if (filePath.exists()) {                                            //Checks if it exists
   FileWriter append = new FileWriter(filePath, true);     //Second check for existing while setting append
   append.write(System.getProperty("line.separator"));             //Adds a line to seperate
   append.write(System.getProperty("line.separator"));             //Adds a line to seperate
   for (String str : reservationInfo) {
    append.write(str);
    append.write("\t\t");
   }
   append.close();//close file
  } else {
   //create filewriter to write to reservations.txt file
   FileWriter reservation = new FileWriter("reservations.txt");
   reservation.write("ID #\t Name\t\t SeatNumber\t\t Flight#\n");
   reservation.write(System.getProperty("line.separator"));             //Adds a line to seperate
   reservation.write(System.getProperty("line.separator"));
   //for loop to add the components into the text file
   for (String str : reservationInfo) {
    reservation.write(str);
    reservation.write("\t\t");
   }
   reservation.close();//close file

   System.out.println("Contents added"); //for debugging
  }



  //FlightReservations reservationID = new FlightReservations(reservationInfo);

  System.out.println("Flight reservation: "+this.reservationID+" created");//for debugging
  //switching to new pane
  System.out.println("Before the pane switch");//Debug purposes
  AnchorPane displayMapPane = FXMLLoader.load(getClass().getResource("SeatMap.fxml")); //Code refuses to go past this point; Day4 of Debugging
  reservationMakerPane.getChildren().setAll(displayMapPane);
  System.out.println("Display changed from initial reservation screen to display seat map");//for debugging

 }

 @FXML
 void goBack(ActionEvent event) throws IOException //Back to menu
 {
  AnchorPane pane = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
  reservationMakerPane.getChildren().setAll(pane);
 }

 @Override
 public void initialize(URL url, ResourceBundle rb)
 {
  // TODO
 }

}
